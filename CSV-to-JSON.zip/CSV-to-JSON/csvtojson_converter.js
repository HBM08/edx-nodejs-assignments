const path = require('path')
const csv = require('csvtojson')
const fs = require('fs')


const convertFile = (fileName = 'customer-data.csv') => {
    
    const fetchFile = (fileName, callback) => {
        let csvFilePath = path.join(__dirname, fileName)
        let jsonBuffer = []
        csv()
        .fromFile(csvFilePath)
        .on('json',(jsonObj)=>{
            jsonBuffer.push(jsonObj);
        })
        .on('done', (error) => { 
            if (error) console.error(`Error: ${error}`)
            callback(null, jsonBuffer, fileName)
        })
    }
    
    fetchFile(fileName, (error, jsonData, fileName) => {
        if (error) return console.log(error)
        let fileNameWithoutType = fileName.substr(0, fileName.length - 4)
        fs.writeFileSync(path.join(__dirname, `${fileNameWithoutType}.json`), JSON.stringify(jsonData))
        console.log(`converting file: ${fileName}  to json`)
    })
}

convertFile(process.argv[2])

